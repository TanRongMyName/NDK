package com.xujun.contralayout.UI.cardView;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.xujun.contralayout.R;

public class CardViewSample extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_view_sample);
    }
}
