package com.xujun.contralayout.UI.zhihu;

import android.view.View;

import com.xujun.contralayout.base.BaseFragment;

/**
 * @author xujun  on 2016/12/3.
 * @email gdutxiaoxu@163.com
 */

public class MeFragment extends BaseFragment {

    @Override
    protected void initView(View view) {

    }

    @Override
    protected int getLayoutId() {
        return 0;
    }

    @Override
    public void fetchData() {

    }
}
