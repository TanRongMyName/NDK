
package com.xujun.contralayout.base.mvp;

/**
 * @author xujun
 *
 * 2017/3/9 16:45.
 */

public interface IBasePresenter {

    void onDestroy();
    void onCreate();
}
