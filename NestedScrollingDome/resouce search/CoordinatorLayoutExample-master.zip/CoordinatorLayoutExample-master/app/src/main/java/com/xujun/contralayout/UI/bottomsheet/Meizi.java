package com.xujun.contralayout.UI.bottomsheet;

/**
 * Created by 赵晨璞 on 2016/6/16.
 */
public class Meizi {
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    private String url;

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    private int page;
}
