package com.xujun.contralayout.base.mvp;

/**
 * @author mobile.xujun on 2017/3/14 17:59
 * @version 0.1
 */

public interface IBaseView<T extends IBasePresenter> {



}
