


## 相关博客



[使用CoordinatorLayout打造各种炫酷的效果](http://blog.csdn.net/gdutxiaoxu/article/details/52858598)

[自定义Behavior —— 仿知乎，FloatActionButton隐藏与展示](http://blog.csdn.net/gdutxiaoxu/article/details/53453958)

[NestedScrolling 机制深入解析](http://blog.csdn.net/gdutxiaoxu/article/details/71553411)

[ 一步步带你读懂 CoordinatorLayout 源码](http://blog.csdn.net/gdutxiaoxu/article/details/71616547)

[自定义 Behavior ——仿新浪微博发现页的实现](http://blog.csdn.net/gdutxiaoxu/article/details/71732642)

----


## 下面我们一起先来看一下我们实现的效果图

仿新浪微博效果图：

![仿新浪微博效果图](https://ww1.sinaimg.cn/mw690/9fe4afa0gy1ffhsjh1sgpg208r0hq1kx.gif)



 结合ToolBar



![](http://ww4.sinaimg.cn/mw690/9fe4afa0jw1f8xclhwlhig208s0etthy.gif)

 结合ViewPager

![ViewPager](http://7xvjnq.com2.z0.glb.qiniucdn.com/16-10-18/99961159.jpg)


 结合ViewPager的视觉特差


![](http://ww2.sinaimg.cn/mw690/9fe4afa0jw1f8xcke8ehkg208s0etnl9.gif)

 **仿知乎**

![](http://7xvjnq.com2.z0.glb.qiniucdn.com/public/16-12-4/86648455.jpg)

![](http://7xvjnq.com2.z0.glb.qiniucdn.com/public/16-12-4/55314155.jpg)

**自定义 Behavior 实现 FloatingActionButton 的隐藏与展示**

- 缩放隐藏的

![](http://7xvjnq.com2.z0.glb.qiniucdn.com/public/16-12-4/95311635.jpg)

- 向上向下隐藏的

![](http://7xvjnq.com2.z0.glb.qiniucdn.com/public/16-12-4/57255134.jpg)

- 左右隐藏的

![](http://ww3.sinaimg.cn/large/9fe4afa0gw1fakqs333ymg208s0gjq6z.gif)

## 题外话

如果觉得效果还不错的，请 star，谢谢。

[使用CoordinatorLayout打造各种炫酷的效果](http://blog.csdn.net/gdutxiaoxu/article/details/52858598)

[自定义Behavior —— 仿知乎，FloatActionButton隐藏与展示](http://blog.csdn.net/gdutxiaoxu/article/details/53453958)

[NestedScrolling 机制深入解析](http://blog.csdn.net/gdutxiaoxu/article/details/71553411)

[ 一步步带你读懂 CoordinatorLayout 源码](http://blog.csdn.net/gdutxiaoxu/article/details/71616547)

[自定义 Behavior ——仿新浪微博发现页的实现](http://blog.csdn.net/gdutxiaoxu/article/details/71732642)
