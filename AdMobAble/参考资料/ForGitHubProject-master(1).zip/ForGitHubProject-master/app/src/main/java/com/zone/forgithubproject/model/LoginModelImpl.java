package com.zone.forgithubproject.model;
import com.zone.forgithubproject.contract.LoginContract;

/**
* Created by john on 2017/03/26
*/

public class LoginModelImpl implements LoginContract.Model{

}