package com.zone.forgithubproject.contract;

/**
 * Created by zone on 2017/3/26.
 */

public class MainContract {
    
public interface View{
}

public interface Presenter{
}

public interface Model{
}


}