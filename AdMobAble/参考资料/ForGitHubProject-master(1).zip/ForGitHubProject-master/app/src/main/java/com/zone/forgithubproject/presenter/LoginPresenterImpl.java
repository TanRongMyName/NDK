package com.zone.forgithubproject.presenter;
import com.zone.forgithubproject.contract.LoginContract;

/**
* Created by john on 2017/03/26
*/

public class LoginPresenterImpl implements LoginContract.Presenter{

}