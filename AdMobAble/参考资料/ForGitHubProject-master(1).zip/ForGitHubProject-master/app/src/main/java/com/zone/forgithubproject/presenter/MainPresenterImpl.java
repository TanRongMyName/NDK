package com.zone.forgithubproject.presenter;
import com.zone.forgithubproject.contract.MainContract;

/**
* Created by john on 2017/03/26
*/

public class MainPresenterImpl implements MainContract.Presenter{

}