# demo_rvadimage

> just博客demo，仅作为教学，勿直接使用。


<img src="anim1.gif" width="320px"/>


<img src="anim2.gif" width="320px"/>